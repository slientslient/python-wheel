from . import displayMousePosition
displayMousePosition()